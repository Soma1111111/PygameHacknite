import pygame
from settings import *
from level import Level
from background import *
from game_data import level_0
import sys
from particle import *
from pygame import mixer
from ui import UI
from overworld import Overworld
pygame.init()

# screen_width = 1080
# screen_height = 640
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
level = Level(level_0, screen)
background = Background(screen_width, screen_height)
my_particle = Particle(particle_position, particle_color, particle_size)
i = 0
mixer.init()
mixer.music.load('stranger-things-124008.mp3')
mixer.music.set_volume(1)
mixer.music.play()
# Set up the loadingen bar dimensions and position
bar_width = 400
bar_height = 40
bar_x = (screen_width - bar_width) // 2
bar_y = (screen_height - bar_height) // 2

# Set up the loading bar colors
bar_bg_color = (200, 200, 200)
bar_fg_color = (50, 150, 50)

# Set up the maximum value of the loading progress
max_value = 100

# Set up the initial value of the loading progress
current_value = 0

# Set up the font for the loading message
font = pygame.font.SysFont('Arial', 24)
'''
class Game:
	def __init__(self):

		# game attributes
		self.max_level = 2
		self.max_health = 100
		self.cur_health = 100
		self.coins = 0

		# overworld creation
		self.overworld = Overworld(0,self.max_level,screen,self.create_level)
		self.status = 'overworld'

		# user interface
		self.ui = UI(screen)

	def create_level(self,current_level):
		self.level = Level(current_level,screen,self.create_overworld,self.change_coins,self.change_health)
		self.status = 'level'

	def create_overworld(self,current_level,new_max_level):
		if new_max_level > self.max_level:
			self.max_level = new_max_level
		self.overworld = Overworld(current_level,self.max_level,screen,self.create_level)
		self.status = 'overworld'

	def change_coins(self,amount):
		self.coins += amount

	def change_health(self,amount):
		self.cur_health += amount

	def check_game_over(self):
		if self.cur_health <= 0:
			self.cur_health = 100
			self.coins = 0
			self.max_level = 0
			self.overworld = Overworld(0,self.max_level,screen,self.create_level)
			self.status = 'overworld'

	def run(self):
		if self.status == 'overworld':
			self.overworld.run()
		else:
			self.level.run()
			self.ui.show_health(self.cur_health,self.max_health)
			self.ui.show_coins(self.coins)
			self.check_game_over()

game = Game()'''
# Define a function to draw the loading bar and progress
def draw_loading_bar():
    # Draw the background of the loading bar
    pygame.draw.rect(screen, bar_bg_color, (bar_x, bar_y, bar_width, bar_height))

    # Calculate the width of the loading bar based on the current progress
    bar_progress = current_value / max_value * bar_width

    # Draw the foreground of the loading bar
    pygame.draw.rect(screen, bar_fg_color, (bar_x, bar_y, bar_progress, bar_height))

    # Draw the loading message
    text = font.render('Loading... {}%'.format(int(current_value / max_value * 100)), True, (255, 255, 255))
    text_rect = text.get_rect(center=(screen_width // 2, screen_height // 2 + 50))
    screen.blit(text, text_rect)
done = False
# Main game loop
running = True

while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and done == True:
                running = False

    # Update the current value based on game progress
    # Here, we're just incrementing the value by 1 every frame for demonstration purposes
    current_value += 0.03
    if current_value >= max_value:
        current_value = max_value
        done = True


    # Clear the screen
    screen.fill((0, 0, 0))

    # Draw the loading bar and progress
    draw_loading_bar()

    # Update the display
    pygame.display.update()


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    screen.fill('black')
    background.draw(screen)
    level.run()
    #game.run()
    key = pygame.key.get_pressed()
    if key[pygame.K_LEFT]:
        background.update_scroll("left")
    if key[pygame.K_RIGHT]:
        background.update_scroll("right")
    my_particle.update_position(path[i % len(path)])
    i += 1
    my_particle.draw(screen)

    pygame.display.update()
    clock.tick(60)
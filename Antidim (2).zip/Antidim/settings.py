vertical_tile_number = 11
screen_width = 1080

tile_size = 48
screen_height = vertical_tile_number * tile_size
screen_width = 1080

'''level_map = [
'                                         ',
'                                         ',
'                                         ',
'                                         ',
'                                         ',
'                                         ',
'                                         ',
'                                         ',
'                                         ',
' P                                       ',
'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',]'''

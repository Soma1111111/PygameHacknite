import pygame
from level import Level


class Background:
    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.screen_height = screen_height

        self.scroll = 0

        self.ground_image = pygame.image.load("plx-0(ground).png").convert_alpha()
        self.ground_width = self.ground_image.get_width()
        self.ground_height = self.ground_image.get_height()

        self.bg_images = []
        for i in range(1, 6):
            bg_image = pygame.image.load(f"plx-{i}.png").convert_alpha()
            self.bg_images.append(bg_image)
            self.bg_width = self.bg_images[0].get_width()

    def draw(self, screen):
        # Draw the background
        self.draw_bg(screen)
        self.draw_ground(screen)

    def draw_bg(self, screen):
        for x in range(15):
            speed = 1
            for i in self.bg_images:
                screen.blit(i, ((x * self.bg_width) - self.scroll * speed, 0))
                speed += 0.2

    def draw_ground(self, screen):
        for x in range(45):
            screen.blit(self.ground_image,
                        ((x * self.ground_width) - self.scroll * 2.5, self.screen_height - self.ground_height))
    def update_scroll(self, direction):
        if direction == "left" and self.scroll > 0 :
            self.scroll -= 2
        elif direction == "right" and self.scroll < 3000:
            self.scroll += 2

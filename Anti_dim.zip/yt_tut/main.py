import pygame
from settings import *
from level import Level
from background import *
from game_data import level_0
import sys
from particle import *
from pygame import mixer
pygame.init()

# screen_width = 1080
# screen_height = 640
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()
level = Level(level_0, screen)
background = Background(screen_width, screen_height)
my_particle = Particle(particle_position, particle_color, particle_size)
i = 0
mixer.music.load('')
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    screen.fill('black')
    background.draw(screen)
    level.run()
    key = pygame.key.get_pressed()
    if key[pygame.K_LEFT]:
        background.update_scroll("left")
    if key[pygame.K_RIGHT]:
        background.update_scroll("right")
    print(path[i % len(path)])
    my_particle.update_position(path[i % len(path)])
    i += 1
    my_particle.draw(screen)

    pygame.display.update()
    clock.tick(60)
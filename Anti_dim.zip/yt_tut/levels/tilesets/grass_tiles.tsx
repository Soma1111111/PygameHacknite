<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="grass_tiles" tilewidth="48" tileheight="48" tilecount="5" columns="5">
 <image source="../../graphics/decoration/grass/grass.png" width="240" height="48"/>
</tileset>

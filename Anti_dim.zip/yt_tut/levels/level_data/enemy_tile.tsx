<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="setup_tile" tilewidth="48" tileheight="48" tilecount="2" columns="2">
 <image source="../../graphics/enemy/setup_tile.png" width="96" height="48"/>
</tileset>

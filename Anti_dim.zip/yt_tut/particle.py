import pygame
import sys
import random
from settings import *

# Initialize Pygame
pygame.init()

# Set up the screen
screen = pygame.display.set_mode((screen_width, screen_height))

# Set up the particle
particle_position = [100, 240]  # Initial position of the particle
particle_size = 3
main_particle_color = (255, 0, 0)
particle_color = (0, 255, 0)
small_particle_size = 1
mini_particle_size = 1

# Define the path
path = [(200, 340), (300, 400), (400, 420), (500, 400), (600, 340), (700, 240), (1000, 300), (600, 250), (740,500), (590, 800), (206, 162),(163, 653),(465,456),(684,465),(789,456),(723,156),(569,578),(564,896),(465,987),(1024,468),(1645,645),(1356,614)]

# Main game loop
class Particle:
    # Update the particle position
    def __init__(self, position, color, size):
        self.position = position
        self.color = color
        self.size = size
        self.small_particles = []

    def update_position(self, next_position):
        if self.position[0] < next_position[0]:
            self.position[0] += random.randint(1, 2)
        elif self.position[0] > next_position[0]:
            self.position[0] -= random.randint(1, 2)
        if self.position[1] < next_position[1]:
            self.position[1] += random.randint(1, 2)
        elif self.position[1] > next_position[1]:
            self.position[1] -= random.randint(1, 2)

        if self.position[0] == next_position[0] and self.position[1] == next_position[1]:
            self.create_small_particles()

    def create_small_particles(self):
        display_position = [particle_position[0], particle_position[1]]
        self.small_particles = []
        small_particle1_position = [display_position[0] + random.randint(-1, 1) * random.randint(3, 9),
                                    display_position[1] + random.randint(-1, 1) * random.randint(3, 9)]
        small_particle2_position = [display_position[0] + random.randint(-1, 1) * random.randint(3, 9),
                                    display_position[1] - random.randint(-1, 1) * random.randint(3, 9)]
        small_particle3_position = [display_position[0] - random.randint(-1, 1) * random.randint(3, 9),
                                    display_position[1] - random.randint(-1, 1) * random.randint(3, 9)]
        small_particle4_position = [display_position[0] - random.randint(-1, 1) * random.randint(3, 9),
                                    display_position[1] + random.randint(-1, 1) * random.randint(3, 9)]

    def draw(self, screen):
        display_position = [particle_position[0], particle_position[1]]
        small_particle1_position = [display_position[0] + random.randint(-1, 1) * random.randint(3, 9),
                                    display_position[1] + random.randint(-1, 1) * random.randint(3, 9)]
        small_particle2_position = [display_position[0] + random.randint(-1, 1) * random.randint(3, 9),
                                    display_position[1] - random.randint(-1, 1) * random.randint(3, 9)]
        small_particle3_position = [display_position[0] - random.randint(-1, 1) * random.randint(3, 9),
                                    display_position[1] - random.randint(-1, 1) * random.randint(3, 9)]
        small_particle4_position = [display_position[0] - random.randint(-1, 1) * random.randint(3, 9),
                                    display_position[1] + random.randint(-1, 1) * random.randint(3, 9)]
        pygame.draw.circle(screen, main_particle_color, particle_position, particle_size)
        pygame.draw.circle(screen, particle_color, small_particle1_position, small_particle_size)
        pygame.draw.circle(screen, particle_color, small_particle2_position, small_particle_size)
        pygame.draw.circle(screen, particle_color, small_particle3_position, small_particle_size)
        pygame.draw.circle(screen, particle_color, small_particle4_position, small_particle_size)
        pygame.display.update()

    '''if len(path) > 0:
        next_position = path[0]
        if particle_position[0] < next_position[0]:
            particle_position[0] += random.randint(1, 2)
        elif particle_position[0] > next_position[0]:
            particle_position[0] -= random.randint(1, 2)
        if particle_position[1] < next_position[1]:
            particle_position[1] += random.randint(1, 2)
        elif particle_position[1] > next_position[1]:
            particle_position[1] -= random.randint(1, 2)
        if particle_position[0] == next_position[0] and particle_position[1] == next_position[1]:
            path.pop(0)


    display_position = [particle_position[0], particle_position[1]]
    small_particle1_position = [display_position[0] + random.randint(-1, 1)*random.randint(3, 9), display_position[1] + random.randint(-1, 1)*random.randint(3, 9)]
    small_particle2_position = [display_position[0] + random.randint(-1, 1)*random.randint(3, 9), display_position[1] - random.randint(-1, 1)*random.randint(3, 9)]
    small_particle3_position = [display_position[0] - random.randint(-1, 1)*random.randint(3, 9), display_position[1] - random.randint(-1, 1)*random.randint(3, 9)]
    small_particle4_position = [display_position[0] - random.randint(-1, 1)*random.randint(3, 9), display_position[1] + random.randint(-1, 1)*random.randint(3, 9)]

    # Draw the particle
    screen.fill((0, 0, 0))
    pygame.draw.circle(screen, main_particle_color, particle_position, particle_size)
    pygame.draw.circle(screen, particle_color, small_particle1_position, small_particle_size)
    pygame.draw.circle(screen, particle_color, small_particle2_position, small_particle_size)
    pygame.draw.circle(screen, particle_color, small_particle3_position, small_particle_size)
    pygame.draw.circle(screen, particle_color, small_particle4_position, small_particle_size)
    pygame.display.update()

    # Add a short delay
    pygame.time.delay(10)'''


'''
#Initialize Pygame

# Set up the screen
screen_width = 1080
screen_height = 640

# Set up the particle
particle_position = [100, 240]  # Initial position of the particle
particle_size = 3
main_particle_color = (255, 0, 0)
particle_color = (0, 255, 0)
small_particle_size = 1
mini_particle_size = 1

# Define the path
path = [(200, 340), (300, 400), (400, 420), (500, 400), (600, 340), (700, 240)]

class Particle:
    def __init__(self, screen, path, particle_color, particle_size, small_particle_size):
        self.path = path
        self.particle_color = particle_color
        self.particle_size = particle_size
        self.small_particle_size = small_particle_size
        self.particle_position = [100, 240]
        self.small_particle_positions = []

    def update(self):
        if len(self.path) > 0:
            next_position = self.path[0]
            if self.particle_position[0] < next_position[0]:
                self.particle_position[0] += random.randint(1, 2)
            elif self.particle_position[0] > next_position[0]:
                self.particle_position[0] -= random.randint(1, 2)
            if self.particle_position[1] < next_position[1]:
                self.particle_position[1] += random.randint(1, 2)
            elif self.particle_position[1] > next_position[1]:
                self.particle_position[1] -= random.randint(1, 2)
            if self.particle_position[0] == next_position[0] and self.particle_position[1] == next_position[1]:
                self.path.pop(0)

        self.small_particle_positions = []
        display_position = [self.particle_position[0], self.particle_position[1]]
        self.small_particle_positions.append([display_position[0] + random.randint(-1, 1)*random.randint(3, 9), display_position[1] + random.randint(-1, 1)*random.randint(3, 9)])
        self.small_particle_positions.append([display_position[0] + random.randint(-1, 1)*random.randint(3, 9), display_position[1] - random.randint(-1, 1)*random.randint(3, 9)])
        self.small_particle_positions.append([display_position[0] - random.randint(-1, 1)*random.randint(3, 9), display_position[1] - random.randint(-1, 1)*random.randint(3, 9)])
        self.small_particle_positions.append([display_position[0] - random.randint(-1, 1)*random.randint(3, 9), display_position[1] + random.randint(-1, 1)*random.randint(3, 9)])

    def draw(self,screen):

        # Draw the particle and small particles
        pygame.draw.circle(screen, main_particle_color, particle_position, particle_size)
        pygame.draw.circle(screen, particle_color, small_particle1_position, small_particle_size)
        pygame.draw.circle(screen, particle_color, small_particle2_position, small_particle_size)
        pygame.draw.circle(screen, particle_color, small_particle3_position, small_particle_size)
        pygame.draw.circle(screen, particle_color, small_particle4_position, small_particle_size)

        # Update the display'''